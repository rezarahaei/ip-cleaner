# IP Cleaners 1.01 — Android Studio project

Initial Kotlin + Jetpack Compose source project. Open this folder in Android Studio (Giraffe or newer; preferably current stable), allow Gradle sync, then Build > Build APK(s).

## Included in this prototype
- First-run Persian/English language choice, persisted for later launches.
- RTL Persian / LTR English interface.
- IP and location lookup with primary/backup public geolocation endpoints.
- VPN transport indicator from Android's active network capabilities (best-effort; this is not a guarantee that all traffic uses the VPN).
- Two-minute refresh while the app is in the foreground.
- Device language/time-zone cards.
- IPFighter open-in-browser action.
- A basic in-app download/upload/latency test using Cloudflare's public speed-test endpoints.
- Settings/about dialogs, version 1.01, developer name.
- Opens Android settings for changes that ordinary apps cannot apply directly.

## Important limitations
- This is source code, not a compiled APK. The environment used to prepare it did not have Gradle installed, so it has not been compiled or tested on a device yet.
- IPFighter's IP Score and its full `IP & Network Issues` panel are not scraped or embedded in this first prototype. The website does not expose a confirmed stable public API here; the app links to the official page rather than fabricating score/issues. A compliant, stable integration needs the site's permission/API or a tested supported interface.
- Android ordinary apps cannot silently change the system-wide language, manual date/time, or time zone just because a permission dialog is accepted. This prototype opens the relevant settings screen. Full automation generally requires device-owner/system privileges or root and is not enabled.
- The speed test is an approximate public-endpoint test, not Ookla Speedtest. Results vary by endpoint, VPN route, radio conditions, and server load. Cloudflare's public endpoints are not guaranteed to be available everywhere.
- Two-minute polling only runs while the app is in the foreground. Android may suspend background work; this prototype does not use a permanent foreground service.
- The requested automatic restore-on-exit is not implemented because Android does not provide a reliable “app exit” event and forcibly stopping an app can bypass cleanup. Use the in-app restore/settings flow instead.

## Build
1. Open this folder in Android Studio.
2. Use JDK 17.
3. Sync Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

Target SDK 35, minimum SDK 23. Dependencies are fetched by Gradle from Google Maven repositories.

## ساخت APK بدون Android Studio (با GitHub Actions)

این پروژه یک workflow برای ساخت آنلاین APK دارد: `.github/workflows/build-apk.yml`.

1. فایل ZIP پروژه را از حالت فشرده خارج کنید.
2. در GitHub یک مخزن جدید بسازید و فایل‌های داخل پوشه `ip_cleaners` را در مخزن بارگذاری کنید (پوشه `.github` نیز باید بارگذاری شود).
3. در صفحه مخزن، زبانه **Actions** را باز کنید و workflow با نام **Build IP Cleaners APK** را انتخاب کنید.
4. روی **Run workflow** بزنید و منتظر پایان اجرای سبز بمانید.
5. وارد اجرای انجام‌شده شوید و از بخش **Artifacts** فایل `IP-Cleaners-1.01-debug-apk` را دانلود کنید.
6. ZIP دانلودشده را باز کنید؛ فایل `app-debug.apk` داخل آن است. آن را به گوشی منتقل و نصب کنید.

نکته: این روش نیازمند حساب GitHub و اینترنت است. APK امضای انتشار (release) ندارد؛ این خروجی debug برای نصب و آزمایش است. این workflow در محیط فعلی اجرا نشده، پس تا وقتی GitHub ساخت موفق را گزارش نکند، کامپایل‌شدن برنامه تضمین‌شده نیست.
